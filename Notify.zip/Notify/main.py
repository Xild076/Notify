from Utility import Notification, check_up, Schedule

if __name__ == '__main__':
    schedule = Schedule()
    schedule._start()